# OvaDetect — Early Detection of Ovarian Cancer

![Python](https://img.shields.io/badge/Python-3.9%2B-blue?style=flat-square&logo=python)
![Flask](https://img.shields.io/badge/Flask-3.0-lightgrey?style=flat-square&logo=flask)
![OpenCV](https://img.shields.io/badge/OpenCV-4.11-green?style=flat-square&logo=opencv)
![License](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)
![Status](https://img.shields.io/badge/Status-Academic%20Prototype-orange?style=flat-square)

> A clinical AI web application for early detection and sub-type classification of ovarian cancer using deep learning, image segmentation, and explainable AI (Grad-CAM).

---

## Features

- **Doctor Authentication** — Secure sign-up and login system
- **Patient Management** — Add patients with medical scan uploads
- **Full AI Pipeline** — Runs automatically on every scan upload:
  - Preprocessing (Noise Removal, Gamma Correction, Histogram Equalization)
  - Segmentation (K-Means + Fuzzy C-Means clustering)
  - Cancer Sub-type Classification (DL Ensemble)
  - Grad-CAM Explainability Heatmap
  - Model Performance Comparison Charts
- **MongoDB Support** — With automatic in-memory fallback
- **Responsive Dark UI** — Premium glassmorphism design

---

## Cancer Sub-types Detected

| Type | Description |
|---|---|
| Serous Carcinoma | Most common, high-grade, papillary architecture |
| Mucinous Carcinoma | Mucin-filled cystic structures |
| Endometrioid Carcinoma | Glandular patterns resembling endometrial tissue |
| Clear Cell Carcinoma | Large polygonal cells with clear cytoplasm |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Web Framework | Flask 3.0 |
| Image Processing | OpenCV 4.11, scikit-image |
| Segmentation | scikit-learn (K-Means), custom Fuzzy C-Means |
| Visualisation | Matplotlib 3.10 |
| Medical Imaging | PyDICOM (DICOM support) |
| Database | MongoDB (pymongo) + in-memory fallback |
| Frontend | HTML5, Vanilla CSS (dark glassmorphism) |
| Auth | Werkzeug password hashing |

---

## Project Structure

```
ovadetect/
├── app.py                  # Flask routes and application logic
├── pipeline.py             # Complete AI/ML processing pipeline
├── models.py               # Database layer (MongoDB + in-memory fallback)
├── requirements.txt        # Python dependencies
├── run.bat                 # One-click Windows launcher
│
├── templates/
│   ├── base.html           # Shared layout (navbar, flash messages, spinner)
│   ├── welcome.html        # Landing page with feature overview
│   ├── login.html          # Doctor login form
│   ├── signup.html         # Doctor registration form
│   ├── dashboard.html      # Patient records list and stats
│   ├── add_patient.html    # Upload scan and trigger analysis
│   └── results.html        # Full pipeline results with visualisations
│
└── static/
    ├── css/style.css       # Complete UI stylesheet
    ├── uploads/            # Uploaded patient scans (runtime, gitignored)
    └── results/            # Generated pipeline outputs (runtime, gitignored)
```

---

## Getting Started

### Prerequisites

- Python 3.9 or higher
- pip

### Option 1 — Windows One-Click

Double-click `run.bat`. It will automatically:
1. Create a Python virtual environment
2. Install all dependencies
3. Start the Flask server at `http://127.0.0.1:5000`

### Option 2 — Manual Setup

```bash
# Clone the repository
git clone https://github.com/<your-username>/ovadetect.git
cd ovadetect

# Create and activate virtual environment
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

Open your browser at **http://127.0.0.1:5000**

---

## AI Pipeline

```
Input Image (PNG / JPG / JPEG / DICOM)
       |
       v
1. Load & Resize to 256x256
       |
       v
2. Preprocessing
   |-- Median Filter       (noise removal)
   |-- Gamma Correction    (gamma = 1.2)
   +-- Histogram Equalization
       |
       v
3. Quality Metrics Graph   (PSNR + SSIM per stage)
       |
       v
4. Segmentation
   |-- K-Means Clustering      (3 clusters)
   +-- Fuzzy C-Means Clustering (3 clusters)
   Both -> highest-intensity cluster = suspected tumour (red)
       |
       v
5. Classification
   +-- Ensemble of 5 CNNs:
       ResNet50, DenseNet121, InceptionV3, VGG19, MobileNetV2
       |
       v
6. Grad-CAM Heatmap        (explainability overlay)
       |
       v
7. Model Comparison Graph  (Accuracy + AUC bar chart)
       |
       v
Output: Full results page with all visualisations
```

---

## Usage Walkthrough

1. Open `http://127.0.0.1:5000`
2. Click **Get Started** and register as a doctor
3. Log in with your Doctor ID and password
4. Click **+ New Patient Analysis**
5. Enter patient name, age and upload a scan image
6. Wait 10–30 seconds for the pipeline to complete
7. View the full report:
   - Original vs preprocessed scan
   - K-Means and Fuzzy C-Means segmentation maps
   - Grad-CAM activation heatmap + clinical justification
   - Cancer sub-type classification + reasoning
   - Model performance comparison bar chart

---

## Database

| Mode | Activated When |
|---|---|
| **MongoDB** | `mongodb://localhost:27017/` is reachable |
| **In-memory** | MongoDB not available (auto fallback, no config needed) |

> Note: In-memory data is lost on server restart. Install and run MongoDB locally for persistent storage.

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `SECRET_KEY` | `ovadetect_super_secret_key_2024` | Flask session secret — change in production |

---

## Supported Image Formats

- `.png` — PNG images
- `.jpg` / `.jpeg` — JPEG images
- `.dcm` / `.dicom` — DICOM medical imaging files

---

## License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) for details.

---

## Disclaimer

> This tool is built for **academic and research purposes only**.  
> It is **not** a certified medical device and must **not** replace professional clinical diagnosis by a qualified healthcare provider.

---

## Acknowledgements

- OpenCV community for image processing utilities
- scikit-learn for K-Means implementation
- Matplotlib for graph generation
- PyDICOM for medical imaging support
- Flask team for the web framework
