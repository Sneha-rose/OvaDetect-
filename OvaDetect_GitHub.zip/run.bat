@echo off
title OvaDetect – Ovarian Cancer Detection System
color 0A

echo.
echo  ========================================================
echo   OvaDetect – Early Ovarian Cancer Detection System
echo  ========================================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.9+ from https://python.org
    pause
    exit /b 1
)

REM Create virtual environment if it doesn't exist
if not exist "venv_run\Scripts\activate.bat" (
    echo [SETUP] Creating virtual environment...
    python -m venv venv_run
    echo [SETUP] Virtual environment created.
    echo.
)

REM Activate
call venv_run\Scripts\activate.bat

REM Install requirements
echo [SETUP] Installing dependencies (this may take a few minutes the first time)...
pip install -q -r requirements.txt
echo [SETUP] All dependencies installed.
echo.

REM Create folders
if not exist "static\uploads" mkdir static\uploads
if not exist "static\results" mkdir static\results

echo  --------------------------------------------------------
echo   Starting Flask server on http://127.0.0.1:5000
echo   Press Ctrl+C to stop.
echo  --------------------------------------------------------
echo.

python app.py

pause
