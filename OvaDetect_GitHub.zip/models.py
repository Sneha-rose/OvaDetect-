"""
models.py – Database layer for OvaDetect.
Tries MongoDB first; falls back to in-memory mock store if unavailable.
"""

import uuid

try:
    from pymongo import MongoClient
    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False


class Database:
    def __init__(self, mongo_uri: str = "mongodb://localhost:27017/", timeout_ms: int = 2000):
        self.mock_db = False
        self.mock_doctors: dict = {}
        self.mock_patients: dict = {}

        if MONGO_AVAILABLE:
            try:
                self.client = MongoClient(mongo_uri, serverSelectionTimeoutMS=timeout_ms)
                self.client.admin.command("ping")            # Fail fast if not running
                self.db = self.client["ovarian_cancer_db"]
                self.doctors  = self.db["doctors"]
                self.patients = self.db["patients"]
                print("[DB] Connected to MongoDB successfully.")
            except Exception as exc:
                print(f"[DB] MongoDB unavailable ({exc}). Using in-memory mock store.")
                self.mock_db = True
        else:
            print("[DB] pymongo not installed. Using in-memory mock store.")
            self.mock_db = True

    # ------------------------------------------------------------------
    # Doctor CRUD
    # ------------------------------------------------------------------
    def get_doctor(self, doctor_id: str):
        if self.mock_db:
            return self.mock_doctors.get(doctor_id)
        return self.doctors.find_one({"doctor_id": doctor_id})

    def create_doctor(self, doctor_id: str, name: str, password_hash: str):
        doctor_data = {
            "doctor_id": doctor_id,
            "name":      name,
            "password":  password_hash,
        }
        if self.mock_db:
            self.mock_doctors[doctor_id] = doctor_data
        else:
            self.doctors.insert_one(doctor_data)

    # ------------------------------------------------------------------
    # Patient CRUD
    # ------------------------------------------------------------------
    def get_patients_for_doctor(self, doctor_id: str):
        if self.mock_db:
            return [p for p in self.mock_patients.values() if p.get("doctor_id") == doctor_id]
        return list(self.patients.find({"doctor_id": doctor_id}))

    def add_patient(self, patient_data: dict) -> str:
        patient_id = str(uuid.uuid4())
        patient_data["_id"] = patient_id
        if self.mock_db:
            self.mock_patients[patient_id] = patient_data
        else:
            self.patients.insert_one(patient_data)
        return patient_id

    def get_patient(self, patient_id: str):
        if self.mock_db:
            return self.mock_patients.get(patient_id)
        return self.patients.find_one({"_id": patient_id})
