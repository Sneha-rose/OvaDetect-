"""
app.py – Flask application entry point for OvaDetect.
Early Detection of Ovarian Cancer – Web Application.
"""

import os
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from models import Database

# ── App Setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "ovadetect_super_secret_key_2024")

UPLOAD_FOLDER  = os.path.join("static", "uploads")
RESULTS_FOLDER = os.path.join("static", "results")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "dcm", "dicom"}

app.config["UPLOAD_FOLDER"]  = UPLOAD_FOLDER
app.config["RESULTS_FOLDER"] = RESULTS_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024   # 32 MB upload limit

os.makedirs(UPLOAD_FOLDER,  exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

db = Database()

# ── Helpers ───────────────────────────────────────────────────────────────────
def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(view_fn):
    """Simple login guard decorator."""
    from functools import wraps
    @wraps(view_fn)
    def wrapper(*args, **kwargs):
        if "doctor_id" not in session:
            flash("Please log in to continue.", "danger")
            return redirect(url_for("login"))
        return view_fn(*args, **kwargs)
    return wrapper

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def welcome():
    return render_template("welcome.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        doctor_id = request.form.get("doctor_id", "").strip()
        name      = request.form.get("name", "").strip()
        password  = request.form.get("password", "")

        if not doctor_id or not name or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("signup"))

        if db.get_doctor(doctor_id):
            flash("Doctor ID already registered. Please log in.", "danger")
            return redirect(url_for("login"))

        db.create_doctor(doctor_id, name, generate_password_hash(password))
        flash("🎉 Registration successful! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        doctor_id = request.form.get("doctor_id", "").strip()
        password  = request.form.get("password", "")

        doctor = db.get_doctor(doctor_id)
        if doctor and check_password_hash(doctor["password"], password):
            session["doctor_id"]   = doctor["doctor_id"]
            session["doctor_name"] = doctor["name"]
            flash(f"Welcome back, Dr. {doctor['name']}! 👋", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid Doctor ID or Password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    doctor_name = session.get("doctor_name", "")
    session.clear()
    flash(f"Goodbye, Dr. {doctor_name}. See you soon!", "info")
    return redirect(url_for("welcome"))


@app.route("/dashboard")
@login_required
def dashboard():
    patients = db.get_patients_for_doctor(session["doctor_id"])
    return render_template("dashboard.html",
                           patients=patients,
                           doctor_name=session["doctor_name"])


@app.route("/add_patient", methods=["GET", "POST"])
@login_required
def add_patient():
    if request.method == "POST":
        patient_name = request.form.get("patient_name", "").strip()
        patient_age  = request.form.get("patient_age", "").strip()

        if not patient_name or not patient_age:
            flash("Patient name and age are required.", "danger")
            return redirect(request.url)

        if "image" not in request.files:
            flash("No file uploaded.", "danger")
            return redirect(request.url)

        file = request.files["image"]
        if file.filename == "":
            flash("Please select an image file.", "danger")
            return redirect(request.url)

        if not allowed_file(file.filename):
            flash("Unsupported file type. Please upload PNG, JPG, JPEG, or DICOM.", "danger")
            return redirect(request.url)

        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(filepath)

        # Run the full ML/DL pipeline
        try:
            import pipeline
            results = pipeline.process_image(filepath, app.config["RESULTS_FOLDER"])
        except Exception as exc:
            flash(f"Pipeline error: {exc}", "danger")
            return redirect(url_for("dashboard"))

        patient_id = db.add_patient({
            "doctor_id":  session["doctor_id"],
            "name":       patient_name,
            "age":        patient_age,
            "image_path": filepath,
            "results":    results,
        })

        flash(f"✅ Analysis complete for {patient_name}.", "success")
        return redirect(url_for("results", patient_id=patient_id))

    return render_template("add_patient.html")


@app.route("/results/<patient_id>")
@login_required
def results(patient_id):
    patient = db.get_patient(patient_id)
    if not patient or patient["doctor_id"] != session["doctor_id"]:
        flash("Patient not found or unauthorised access.", "danger")
        return redirect(url_for("dashboard"))
    return render_template("results.html", patient=patient)


# ── Error Handlers ────────────────────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return render_template("welcome.html"), 404

@app.errorhandler(413)
def file_too_large(e):
    flash("File is too large. Maximum upload size is 32 MB.", "danger")
    return redirect(url_for("add_patient"))

# ── Entry Point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "="*60)
    print("  OvaDetect -- Early Ovarian Cancer Detection System")
    print("  Running at: http://127.0.0.1:5000")
    print("="*60 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
